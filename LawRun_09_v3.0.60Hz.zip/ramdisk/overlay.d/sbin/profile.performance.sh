#!/system/bin/sh

#Stop perfd and remove its default values
stop perfd
rm /data/vendor/perfd/default_values

#CPU MANAGMENT
echo "1516800" > /sys/module/cpu_input_boost/parameters/input_boost_freq_lp
echo "1363200" > /sys/module/cpu_input_boost/parameters/input_boost_freq_hp
echo "125" > /sys/module/cpu_input_boost/parameters/input_boost_duration

# SILVER Cluster
echo "300000" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
echo "1766400" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq

# GOLD Cluster
echo "825600" > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
echo "2803200" > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq

#GPU
echo "257000000" > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq 
echo "257000000" > /sys/class/kgsl/kgsl-3d0/min_gpuclk
echo "710000000" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq 
echo "710000000" > /sys/class/kgsl/kgsl-3d0/max_gpuclk

#Charging Script
echo "2800000" > /sys/class/power_supply/battery/constant_charge_current_max

#start perfd back
start perfd
