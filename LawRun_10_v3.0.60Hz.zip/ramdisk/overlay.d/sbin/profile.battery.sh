#!/system/bin/sh

#Stop perfd and remove its default values
stop perfd
rm /data/vendor/perfd/default_values

#CPU MANAGMENT
echo "979200" > /sys/module/cpu_input_boost/parameters/input_boost_freq_lp
echo "0" > /sys/module/cpu_input_boost/parameters/input_boost_freq_hp
echo "32" > /sys/module/cpu_input_boost/parameters/input_boost_duration

# SILVER Cluster
echo "300000" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq
echo "1516800" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq

# GOLD Cluster
echo "825600" > /sys/devices/system/cpu/cpu4/cpufreq/scaling_min_freq
echo "1056000" > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq

#GPU
echo "157000000" > /sys/class/kgsl/kgsl-3d0/devfreq/min_freq 
echo "157000000" > /sys/class/kgsl/kgsl-3d0/min_gpuclk
echo "520000000" > /sys/class/kgsl/kgsl-3d0/devfreq/max_freq 
echo "520000000" > /sys/class/kgsl/kgsl-3d0/max_gpuclk

#Charging Script
echo "3300000" > /sys/class/power_supply/battery/constant_charge_current_max

#start perfd back
start perfd
